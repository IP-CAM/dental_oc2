<?php
$_['text_wait']         = 'Por favor, aguarde!';
$_['button_confirm'] = 'Pagar com o banco escolhido';
?>